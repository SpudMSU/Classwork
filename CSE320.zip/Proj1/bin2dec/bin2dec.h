#ifndef _BIN2DEC_H
#define _BIN2DEC_H
#endif

/**
 * @file
 * Header file that declares the bin2dec function
 */

unsigned int bin2dec(const char *binary);
