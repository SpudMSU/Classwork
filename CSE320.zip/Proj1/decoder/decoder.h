#ifndef _DECODER_H
#define _DECODER_H
#endif

/*
 * Header file with the prototype for decoder
 */

void decoder(const char *encoded, char *decoded, int maxLen);
