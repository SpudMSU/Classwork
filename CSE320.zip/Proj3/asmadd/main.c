#include <stdio.h>

int add(int, int, int, int);

int main() 
{
  printf("%d\n", add(3, 5, 7, 9));
  return 0;
}
